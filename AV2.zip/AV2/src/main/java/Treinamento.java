public interface Treinamento {

    public abstract void  treinarPadawan();

}
