public interface Forca {

    public abstract void usarForca();

    public abstract void trocarSabre(String cor);
}
